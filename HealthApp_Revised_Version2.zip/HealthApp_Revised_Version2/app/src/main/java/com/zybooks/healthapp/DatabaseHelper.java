package com.zybooks.healthapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "healthapp.db";
    private static final int DATABASE_VERSION = 2; // increment version

    // Table for users
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_GOAL_WEIGHT = "goal_Weight";

    // Table for weight entries
    private static final String TABLE_WEIGHT = "weight_entries";
    public static final String COLUMN_ID = "id";
    private static final String COLUMN_USER = "user";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    // Table for food entries
    private static final String TABLE_FOOD = "food_entries";
    private static final String COLUMN_FOOD_ID = "id";
    private static final String COLUMN_FOOD_USER = "user";
    private static final String COLUMN_FOOD_DATE = "date";
    private static final String COLUMN_FOOD_NOTES = "notes";

    // SQL statements
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL," +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_GOAL_WEIGHT + " FLOAT);";

    private static final String CREATE_WEIGHT_TABLE =
            "CREATE TABLE " + TABLE_WEIGHT + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER + " TEXT NOT NULL, " +
                    COLUMN_DATE + " TEXT NOT NULL, " +
                    COLUMN_WEIGHT + " FLOAT NOT NULL, " +
                    "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "));";

    private static final String CREATE_FOOD_TABLE =
            "CREATE TABLE " + TABLE_FOOD + " (" +
                    COLUMN_FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_FOOD_USER + " TEXT NOT NULL, " +
                    COLUMN_FOOD_DATE + " TEXT NOT NULL, " +
                    COLUMN_FOOD_NOTES + " TEXT, " +
                    "FOREIGN KEY(" + COLUMN_FOOD_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "));";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHT_TABLE);
        db.execSQL(CREATE_FOOD_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Drop old table
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOOD);
            db.execSQL(CREATE_FOOD_TABLE);

        }
    }

    //user methods

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean insertUser(String name, String username, String password, float goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean updateUser(String oldUsername, String newUsername, String newPassword, String newName, double newGoalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            db.beginTransaction();

            // Update weight entries if username is changed
            if (!oldUsername.equals(newUsername)) {
                ContentValues weightValues = new ContentValues();
                weightValues.put(COLUMN_USER, newUsername);
                db.update(TABLE_WEIGHT, weightValues, COLUMN_USER + "=?", new String[]{oldUsername});

                // Update food entries if the username is changed
                ContentValues foodValues = new ContentValues();
                foodValues.put(COLUMN_FOOD_USER, newUsername);
                db.update(TABLE_FOOD, foodValues, COLUMN_FOOD_USER + "=?", new String[]{oldUsername});
            }

            // Updates user information
            ContentValues values = new ContentValues();
            if (newUsername != null && !newUsername.isEmpty()) {
                values.put(COLUMN_USERNAME, newUsername);
            }
            if (newPassword != null && !newPassword.isEmpty()) {
                values.put(COLUMN_PASSWORD, newPassword);
            }
            if (newName != null && !newName.isEmpty()) {
                values.put(COLUMN_NAME, newName);
            }
            if (newGoalWeight >= 0) {
                values.put(COLUMN_GOAL_WEIGHT, newGoalWeight);
            }

            int rows = db.update(TABLE_USERS, values, COLUMN_USERNAME + "=?", new String[]{oldUsername});

            if (rows > 0) {
                db.setTransactionSuccessful();
                return true;
            }
            return false;

        } finally {
            db.endTransaction();
        }
    }

    public User getUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?", new String[]{username});

        if (cursor != null && cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex(COLUMN_NAME);
            int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
            int goalWeightIndex = cursor.getColumnIndex(COLUMN_GOAL_WEIGHT);

            if (nameIndex == -1 || passwordIndex == -1 || goalWeightIndex == -1) {
                cursor.close();
                return null;
            }

            String name = cursor.getString(nameIndex);
            String password = cursor.getString(passwordIndex);
            double goalWeight = cursor.getDouble(goalWeightIndex);

            User user = new User(name, username, password, goalWeight);
            cursor.close();
            return user;
        } else {
            cursor.close();
            return null;
        }
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // methods for weight entry

    public boolean insertWeight(String user, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER, user);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    public Cursor getWeightEntries(String user) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " WHERE " + COLUMN_USER + "=?", new String[]{user});
    }

    public boolean updateWeightEntry(int id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHT, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHT, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public float getLatestWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " WHERE " + COLUMN_USER + " = ? ORDER BY " + COLUMN_DATE + " DESC LIMIT 1", new String[]{username});
        if (cursor != null && cursor.moveToFirst()) {
            int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
            float weight = cursor.getFloat(weightIndex);
            cursor.close();
            return weight;
        } else {
            cursor.close();
            return -1;
        }
    }

    // food diary methods

    // Save or update food notes
    public boolean saveFoodNotes(String user, String date, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if entry is existing
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_FOOD +
                        " WHERE " + COLUMN_FOOD_USER + "=? AND " + COLUMN_FOOD_DATE + "=?",
                new String[]{user, date});

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        ContentValues values = new ContentValues();
        values.put(COLUMN_FOOD_USER, user);
        values.put(COLUMN_FOOD_DATE, date);
        values.put(COLUMN_FOOD_NOTES, notes);

        if (exists) {
            // Update existing note
            int rows = db.update(TABLE_FOOD, values,
                    COLUMN_FOOD_USER + "=? AND " + COLUMN_FOOD_DATE + "=?",
                    new String[]{user, date});
            return rows > 0;
        } else {
            // Insert new entry
            long result = db.insert(TABLE_FOOD, null, values);
            return result != -1;
        }
    }

    // Get food notes for a certain day
    public String getFoodNotes(String user, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_FOOD_NOTES + " FROM " + TABLE_FOOD +
                        " WHERE " + COLUMN_FOOD_USER + "=? AND " + COLUMN_FOOD_DATE + "=?",
                new String[]{user, date});

        String notes = "";
        if (cursor.moveToFirst()) {
            int notesIndex = cursor.getColumnIndex(COLUMN_FOOD_NOTES);
            if (notesIndex != -1) {
                notes = cursor.getString(notesIndex);
                if (notes == null) {
                    notes = "";
                }
            }
        }
        cursor.close();
        return notes;
    }

    // Check if day has notes/ count
    public int getFoodEntryCount(String username, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_FOOD_NOTES + " FROM " + TABLE_FOOD +
                        " WHERE " + COLUMN_FOOD_USER + " = ? AND " + COLUMN_FOOD_DATE + " = ?",
                new String[]{username, date}
        );

        int count = 0;
        if (cursor.moveToFirst()) {
            int notesIndex = cursor.getColumnIndex(COLUMN_FOOD_NOTES);
            if (notesIndex != -1) {
                String notes = cursor.getString(notesIndex);
                if (notes != null && !notes.trim().isEmpty()) {
                    count = 1;
                }
            }
        }
        cursor.close();
        return count;
    }
}