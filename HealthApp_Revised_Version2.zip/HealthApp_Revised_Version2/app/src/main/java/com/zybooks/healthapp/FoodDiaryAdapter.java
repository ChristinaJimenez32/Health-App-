package com.zybooks.healthapp;
import android.content.Intent;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FoodDiaryAdapter extends RecyclerView.Adapter<FoodDiaryAdapter.DayViewHolder> {

    private List<DayEntry> dayEntries;
    private Context context;
    private String username;
    private DatabaseHelper databaseHelper;

    public FoodDiaryAdapter(List<DayEntry> dayEntries, Context context, String username, DatabaseHelper databaseHelper) {
        this.dayEntries = dayEntries;
        this.context = context;
        this.username = username;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.food_diary_row_layout, parent, false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        DayEntry day = dayEntries.get(position);

        holder.dayOfWeekTextView.setText(day.getDayOfWeek());
        holder.dateTextView.setText(day.getDate());
        holder.mealSummaryTextView.setText(day.getMealSummary());

        // Click listener to open EditFoodEntryActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditFoodEntryActivity.class);
            intent.putExtra("username", username);
            intent.putExtra("date", day.getDateString());
            intent.putExtra("dayOfWeek", day.getDayOfWeek());
            intent.putExtra("dateDisplay", day.getDate());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return dayEntries.size();
    }

    public void updateData(List<DayEntry> newDays) {
        this.dayEntries = newDays;
        notifyDataSetChanged();
    }

    static class DayViewHolder extends RecyclerView.ViewHolder {
        TextView dayOfWeekTextView;
        TextView dateTextView;
        TextView mealSummaryTextView;

        public DayViewHolder(@NonNull View itemView) {
            super(itemView);
            dayOfWeekTextView = itemView.findViewById(R.id.textViewDayOfWeek);
            dateTextView = itemView.findViewById(R.id.textViewDate);
            mealSummaryTextView = itemView.findViewById(R.id.textViewMealSummary);
        }
    }
}