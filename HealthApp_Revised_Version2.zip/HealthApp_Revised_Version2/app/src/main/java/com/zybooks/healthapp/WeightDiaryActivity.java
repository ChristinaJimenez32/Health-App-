package com.zybooks.healthapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.android.material.navigation.NavigationView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class WeightDiaryActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener,
        WeightAdapter.OnDeleteClickListener,
        WeightAdapter.OnItemClickListener {

    private RecyclerView weightRecyclerView;
    private WeightAdapter weightAdapter;
    private DatabaseHelper databaseHelper;
    private String currentUsername;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private List<WeightEntry> allWeightEntries;
    private List<WeightEntry> currentWeekEntries;
    private EditText weightEditText;
    private EditText dateEditText;
    private Button submitWeightButton;
    private Button btnPreviousWeek;
    private Button btnNextWeek;
    private TextView textViewWeekLabel;
    private TextView textViewChartMonth;
    private LineChart lineChart;
    private Calendar selectedDate;
    private Calendar currentWeekStart;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_grid);

        // Retrieve the username from intent
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize date format and calendar
        dateFormat = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
        selectedDate = Calendar.getInstance();
        currentWeekStart = WeekHelper.getWeekStart(Calendar.getInstance());

        // Initialize views
        initializeViews();

        // Setup chart
        setupChart();

        // Load all weight entries
        loadAllWeightEntries();

        // Display current week
        displayWeek(currentWeekStart);

        // Setup date picker
        setupDatePicker();

        // Setup week navigation
        setupWeekNavigation();

        // Setup submit button
        setupSubmitButton();

        // Setup drawer
        setupDrawer();
    }

    private void initializeViews() {
        weightRecyclerView = findViewById(R.id.recyclerView);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightRecyclerView.setHasFixedSize(false);

        lineChart = findViewById(R.id.lineChart);
        weightEditText = findViewById(R.id.editTextWeight);
        dateEditText = findViewById(R.id.editTextDate);
        submitWeightButton = findViewById(R.id.buttonAdd);
        btnPreviousWeek = findViewById(R.id.btnPreviousWeek);
        btnNextWeek = findViewById(R.id.btnNextWeek);
        textViewWeekLabel = findViewById(R.id.textViewWeekLabel);
        textViewChartMonth = findViewById(R.id.textViewChartMonth);

        // Set todays date default
        dateEditText.setText(dateFormat.format(selectedDate.getTime()));
    }

    private void setupWeekNavigation() {
        btnPreviousWeek.setOnClickListener(v -> {
            currentWeekStart.add(Calendar.WEEK_OF_YEAR, -1);
            displayWeek(currentWeekStart);
        });

        btnNextWeek.setOnClickListener(v -> {
            currentWeekStart.add(Calendar.WEEK_OF_YEAR, 1);
            displayWeek(currentWeekStart);
        });
    }

    private void displayWeek(Calendar weekStart) {
        // Update week label
        textViewWeekLabel.setText(WeekHelper.getWeekLabel(weekStart));

        // Filter entries for week
        currentWeekEntries = new ArrayList<>();
        Calendar weekEnd = WeekHelper.getWeekEnd(weekStart);

        for (WeightEntry entry : allWeightEntries) {
            try {
                Calendar entryDate = Calendar.getInstance();
                entryDate.setTime(dateFormat.parse(entry.getDate()));

                if (!entryDate.before(weekStart) && !entryDate.after(weekEnd)) {
                    currentWeekEntries.add(entry);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        // Update RecyclerView
        if (weightAdapter == null) {
            weightAdapter = new WeightAdapter(currentWeekEntries, this, this);
            weightRecyclerView.setAdapter(weightAdapter);
        } else {
            weightAdapter.updateData(currentWeekEntries);
        }
    }

    private void setupDatePicker() {
        dateEditText.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    R.style.CustomDatePickerTheme,
                    (view, year, month, dayOfMonth) -> {
                        selectedDate.set(Calendar.YEAR, year);
                        selectedDate.set(Calendar.MONTH, month);
                        selectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        dateEditText.setText(dateFormat.format(selectedDate.getTime()));
                    },
                    selectedDate.get(Calendar.YEAR),
                    selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH)
            );

            // Restrict last 3 months
            Calendar threeMonthsAgo = Calendar.getInstance();
            threeMonthsAgo.add(Calendar.MONTH, -3);
            datePickerDialog.getDatePicker().setMinDate(threeMonthsAgo.getTimeInMillis());
            datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());

            datePickerDialog.show();
        });
    }

    private void setupSubmitButton() {
        submitWeightButton.setOnClickListener(v -> {
            String weightStr = weightEditText.getText().toString().trim();
            String dateStr = dateEditText.getText().toString().trim();

            if (weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dateStr.isEmpty()) {
                Toast.makeText(this, "Please select a date.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float weight = Float.parseFloat(weightStr);
                Calendar entryDate = Calendar.getInstance();
                entryDate.setTime(dateFormat.parse(dateStr));

                // Check if entry already exists for day
                boolean dayHasEntry = false;
                for (WeightEntry entry : allWeightEntries) {
                    try {
                        Calendar existingDate = Calendar.getInstance();
                        existingDate.setTime(dateFormat.parse(entry.getDate()));

                        if (WeekHelper.isSameDay(entryDate, existingDate)) {
                            dayHasEntry = true;
                            Toast.makeText(this, "Entry already exists for this day. Edit the existing entry instead.",
                                    Toast.LENGTH_LONG).show();
                            break;
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }

                if (!dayHasEntry) {
                    // Insert the new weight entry
                    boolean success = databaseHelper.insertWeight(currentUsername, dateStr, weight);

                    if (success) {
                        Toast.makeText(this, "Weight entry added!", Toast.LENGTH_SHORT).show();
                        loadAllWeightEntries();

                        // Week new entry
                        currentWeekStart = WeekHelper.getWeekStart(entryDate);
                        displayWeek(currentWeekStart);
                        updateChart();

                        weightEditText.setText("");
                        selectedDate = Calendar.getInstance();
                        dateEditText.setText(dateFormat.format(selectedDate.getTime()));
                    } else {
                        Toast.makeText(this, "Failed to add weight entry.", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight format.", Toast.LENGTH_SHORT).show();
            } catch (ParseException e) {
                Toast.makeText(this, "Invalid date format.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupChart() {
        lineChart.getDescription().setEnabled(false);
        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);
        lineChart.setPinchZoom(true);
        lineChart.setDrawGridBackground(false);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setTextColor(Color.parseColor("#666666"));

        lineChart.getAxisRight().setEnabled(false);
        lineChart.getAxisLeft().setTextColor(Color.parseColor("#666666"));
        lineChart.getLegend().setEnabled(false);
    }

    private void updateChart() {
        // Get current month entries for chart
        Calendar now = Calendar.getInstance();
        int currentMonth = now.get(Calendar.MONTH);
        int currentYear = now.get(Calendar.YEAR);

        textViewChartMonth.setText(WeekHelper.getMonthYear(now));

        List<WeightEntry> monthEntries = new ArrayList<>();
        for (WeightEntry entry : allWeightEntries) {
            try {
                Calendar entryDate = Calendar.getInstance();
                entryDate.setTime(dateFormat.parse(entry.getDate()));

                if (entryDate.get(Calendar.MONTH) == currentMonth &&
                        entryDate.get(Calendar.YEAR) == currentYear) {
                    monthEntries.add(entry);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        if (monthEntries.isEmpty()) {
            lineChart.clear();
            return;
        }

        ArrayList<Entry> entries = new ArrayList<>();
        for (int i = 0; i < monthEntries.size(); i++) {
            entries.add(new Entry(i, monthEntries.get(i).getWeight()));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Weight");
        int primaryColor = getResources().getColor(R.color.sky_blue);

        dataSet.setColor(primaryColor);
        dataSet.setCircleColor(primaryColor);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawCircleHole(false);
        dataSet.setValueTextSize(10f);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(primaryColor);
        dataSet.setFillAlpha(50);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData lineData = new LineData(dataSet);
        lineChart.setData(lineData);
        lineChart.animateX(1000);
        lineChart.invalidate();
    }

    private void loadAllWeightEntries() {
        allWeightEntries = new ArrayList<>();
        Cursor cursor = databaseHelper.getWeightEntries(currentUsername);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT));
                allWeightEntries.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }

        updateChart();
    }

    @Override
    public void onDeleteClick(WeightEntry weightEntry) {
        boolean deleted = databaseHelper.deleteWeightEntry(weightEntry.getId());
        if (deleted) {
            Toast.makeText(this, "Entry deleted!", Toast.LENGTH_SHORT).show();
            loadAllWeightEntries();
            displayWeek(currentWeekStart);
        } else {
            Toast.makeText(this, "Delete failed!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemClick(WeightEntry weightEntry) {
        showEditWeightDialog(weightEntry);
    }

    private void showEditWeightDialog(WeightEntry weightEntry) {
        final EditText editWeightInput = new EditText(this);
        editWeightInput.setText(String.valueOf(weightEntry.getWeight()));

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry")
                .setView(editWeightInput)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newWeightStr = editWeightInput.getText().toString().trim();

                    if (newWeightStr.isEmpty()) {
                        Toast.makeText(this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    float newWeight = Float.parseFloat(newWeightStr);
                    boolean success = databaseHelper.updateWeightEntry(weightEntry.getId(), newWeight);

                    if (success) {
                        Toast.makeText(this, "Weight entry updated!", Toast.LENGTH_SHORT).show();
                        loadAllWeightEntries();
                        displayWeek(currentWeekStart);
                    } else {
                        Toast.makeText(this, "Failed to update weight entry.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void setupDrawer() {
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            Toast.makeText(this, "You are already in Weight Diary", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_food_diary) {
            Intent intent = new Intent(this, FoodDiaryActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_sms_notification) {
            startActivity(new Intent(this, NotificationActivity.class));
        } else if (id == R.id.nav_user_profile) {
            Intent intent = new Intent(this, EditAccountActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}