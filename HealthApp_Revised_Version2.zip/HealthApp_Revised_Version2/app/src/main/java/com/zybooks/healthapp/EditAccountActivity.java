package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class EditAccountActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // EditText declarations
    EditText nameEditText;
    EditText usernameEditText;
    EditText passwordEditText;
    EditText goalWeightEditText;

    // Button declarations
    Button updateButton;
    Button cancelButton;

    // Database helper instance
    DatabaseHelper databaseHelper;
    String currentUsername;

    // Store original values for comparison
    private String originalName;
    private String originalUsername;
    private String originalPassword;
    private double originalGoalWeight;

    // Drawer elements
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile);

        // Retrieve username from intent
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");

        // Initialize UI components
        nameEditText = findViewById(R.id.nameEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);

        // Button elements
        updateButton = findViewById(R.id.editAccountButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Initially disable the update button
        updateButton.setEnabled(false);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load user data from the database
        loadUserData(currentUsername);

        // Text change listener
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateButton.setEnabled(true);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        // Add TextWatcher to each EditText
        nameEditText.addTextChangedListener(textWatcher);
        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);
        goalWeightEditText.addTextChangedListener(textWatcher);

        // Button click listener to update user info
        updateButton.setOnClickListener(v -> updateUserDetails());

        // Cancel button click listener to exit activity
        cancelButton.setOnClickListener(v -> {
            Intent intent1 = new Intent(EditAccountActivity.this, WeightDiaryActivity.class);
            intent1.putExtra("username", currentUsername);
            startActivity(intent1);
            finish();
        });

        // Setups DrawerLayout and NavigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void loadUserData(String currentUsername) {
        User user = databaseHelper.getUser(currentUsername);
        if (user != null) {
            // Store original values
            originalName = user.getName();
            originalUsername = user.getUsername();
            originalPassword = user.getPassword();
            originalGoalWeight = user.getGoalWeight();

            // Set fields
            nameEditText.setText(originalName);
            usernameEditText.setText(originalUsername);
            passwordEditText.setText(originalPassword);
            goalWeightEditText.setText(String.valueOf(originalGoalWeight));
        }
    }

    private void updateUserDetails() {
        // Get new values
        String newName = nameEditText.getText().toString().trim();
        String newUsername = usernameEditText.getText().toString().trim();
        String newPassword = passwordEditText.getText().toString().trim();
        String goalWeightStr = goalWeightEditText.getText().toString().trim();

        // Validate required fields
        if (newName.isEmpty() || newUsername.isEmpty() || newPassword.isEmpty() || goalWeightStr.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        double newGoalWeight;
        try {
            newGoalWeight = Double.parseDouble(goalWeightStr);
            if (newGoalWeight <= 0) {
                goalWeightEditText.setError("Weight must be positive");
                return;
            }
        } catch (NumberFormatException e) {
            goalWeightEditText.setError("Invalid weight");
            return;
        }

        // Check if anything changed
        boolean hasChanges = !newName.equals(originalName) ||
                !newUsername.equals(originalUsername) ||
                !newPassword.equals(originalPassword) ||
                newGoalWeight != originalGoalWeight;

        if (!hasChanges) {
            Toast.makeText(this, "No changes detected", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username changed and if new username already exists in db
        if (!newUsername.equals(originalUsername)) {
            if (databaseHelper.usernameExists(newUsername)) {
                usernameEditText.setError("Username already exists");
                Toast.makeText(this, "Username already taken", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Update the user data in the database
        boolean isUpdated = databaseHelper.updateUser(currentUsername, newUsername, newPassword, newName, newGoalWeight);

        if (isUpdated) {
            // Update currentUsername if it changed
            currentUsername = newUsername;

            Toast.makeText(this, "Account updated successfully!", Toast.LENGTH_SHORT).show();

            // Pass the updated username back to WeightDiaryActivity
            Intent intent = new Intent(EditAccountActivity.this, WeightDiaryActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            Intent intent = new Intent(this, WeightDiaryActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_food_diary) {
            Intent intent = new Intent(this, FoodDiaryActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_sms_notification) {
            Intent intent = new Intent(this, NotificationActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_user_profile) {
            Toast.makeText(this, "You are already in User Profile", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}