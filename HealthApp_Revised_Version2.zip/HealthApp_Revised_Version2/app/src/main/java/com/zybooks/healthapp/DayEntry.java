package com.zybooks.healthapp;

public class DayEntry {
    private String dayOfWeek;
    private String date;
    private String dateString;
    private int entryCount;

    public DayEntry() {
        this.entryCount = 0;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDateString() {
        return dateString;
    }

    public void setDateString(String dateString) {
        this.dateString = dateString;
    }

    public int getEntryCount() {
        return entryCount;
    }

    public void setEntryCount(int entryCount) {
        this.entryCount = entryCount;
    }

    // displays message based on diary entries for day
    public String getMealSummary() {
        if (entryCount == 0) {
            return "No entries yet - Tap to add";
        } else if (entryCount == 1) {
            return "1 meal logged";
        } else {
            return entryCount + " meals logged";
        }
    }
}
