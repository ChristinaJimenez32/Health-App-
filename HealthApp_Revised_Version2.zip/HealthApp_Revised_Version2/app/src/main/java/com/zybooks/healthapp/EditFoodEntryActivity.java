package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class EditFoodEntryActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    // Declares widgets
    private TextView textViewDayHeader;
    private TextView textViewDateHeader;
    private EditText editTextFoodNotes;
    private Button buttonSave;

    private DatabaseHelper databaseHelper;
    private String username;
    private String date;
    private String dayOfWeek;
    private String dateDisplay;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_food);

        // Get data from intent
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        date = intent.getStringExtra("date");
        dayOfWeek = intent.getStringExtra("dayOfWeek");
        dateDisplay = intent.getStringExtra("dateDisplay");

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        //Initialize views
        textViewDayHeader = findViewById(R.id.textViewDayHeader);
        textViewDateHeader = findViewById(R.id.textViewDateHeader);
        editTextFoodNotes = findViewById(R.id.editTextFoodNotes);
        buttonSave = findViewById(R.id.buttonSave);

        // Set header text
        textViewDayHeader.setText(dayOfWeek);
        textViewDateHeader.setText(dateDisplay);

        // Load existing notes
        String existingNotes = databaseHelper.getFoodNotes(username, date);
        editTextFoodNotes.setText(existingNotes);

        // Click Listener for Button
        buttonSave.setOnClickListener(v -> saveNotes());

        // Setup drawer
        setupDrawer();
    }

    private void saveNotes() {
        String notes = editTextFoodNotes.getText().toString().trim();

        boolean success = databaseHelper.saveFoodNotes(username, date, notes);

        //Returns to food diary
        if (success) {
            Toast.makeText(this, "Notes saved!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to save notes", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupDrawer() {
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Food Notes");

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            Intent intent = new Intent(this, WeightDiaryActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_food_diary) {
            finish();
        } else if (id == R.id.nav_sms_notification) {
            Intent intent = new Intent(this, NotificationActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_user_profile) {
            Intent intent = new Intent(this, EditAccountActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}