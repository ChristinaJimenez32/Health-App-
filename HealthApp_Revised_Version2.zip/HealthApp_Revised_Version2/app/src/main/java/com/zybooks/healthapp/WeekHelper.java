package com.zybooks.healthapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class WeekHelper {

    public static Calendar getWeekStart(Calendar date) {
        Calendar weekStart = (Calendar) date.clone();
        weekStart.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        weekStart.set(Calendar.HOUR_OF_DAY, 0);
        weekStart.set(Calendar.MINUTE, 0);
        weekStart.set(Calendar.SECOND, 0);
        weekStart.set(Calendar.MILLISECOND, 0);
        return weekStart;
    }

    public static Calendar getWeekEnd(Calendar date) {
        Calendar weekEnd = (Calendar) date.clone();
        weekEnd.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
        weekEnd.set(Calendar.HOUR_OF_DAY, 23);
        weekEnd.set(Calendar.MINUTE, 59);
        weekEnd.set(Calendar.SECOND, 59);
        return weekEnd;
    }

    public static String getWeekLabel(Calendar weekStart) {
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", Locale.getDefault());
        SimpleDateFormat dayFormat = new SimpleDateFormat("d", Locale.getDefault());

        return "Week of " + monthFormat.format(weekStart.getTime()) + " " +
                dayFormat.format(weekStart.getTime());
    }

    public static String getMonthYear(Calendar date) {
        SimpleDateFormat format = new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
        return format.format(date.getTime());
    }

    public static boolean isInWeek(Calendar date, Calendar weekStart) {
        Calendar weekEnd = getWeekEnd(weekStart);
        return !date.before(weekStart) && !date.after(weekEnd);
    }

    public static boolean isSameDay(Calendar date1, Calendar date2) {
        return date1.get(Calendar.YEAR) == date2.get(Calendar.YEAR) &&
                date1.get(Calendar.DAY_OF_YEAR) == date2.get(Calendar.DAY_OF_YEAR);
    }
}