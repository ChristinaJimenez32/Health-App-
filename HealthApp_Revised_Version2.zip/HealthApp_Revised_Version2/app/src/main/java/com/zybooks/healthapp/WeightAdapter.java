package com.zybooks.healthapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<WeightEntry> weightEntries;
    private OnDeleteClickListener deleteClickListener;
    private OnItemClickListener itemClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(WeightEntry weightEntry);
    }

    public interface OnItemClickListener {
        void onItemClick(WeightEntry weightEntry);
    }

    public WeightAdapter(List<WeightEntry> weightEntries, OnDeleteClickListener deleteClickListener, OnItemClickListener itemClickListener) {
        this.weightEntries = weightEntries;
        this.deleteClickListener = deleteClickListener;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);

        // Get day of week from date
        String dayOfWeek = getDayOfWeek(entry.getDate());

        holder.dayOfWeekTextView.setText(dayOfWeek);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(String.format("%.1f lbs", entry.getWeight()));

        // Delete button click
        holder.deleteButton.setOnClickListener(v -> deleteClickListener.onDeleteClick(entry));

        // Editing
        holder.itemView.setOnClickListener(v -> itemClickListener.onItemClick(entry));
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    // Updates data
    public void updateData(List<WeightEntry> newEntries) {
        this.weightEntries = newEntries;
        notifyDataSetChanged();
    }

    // Helper method to get day of week from date string
    private String getDayOfWeek(String dateString) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
            Date date = inputFormat.parse(dateString);
            SimpleDateFormat outputFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Unknown";
        }
    }

    // Holder for recycler
    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dayOfWeekTextView, dateTextView, weightTextView;
        Button deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dayOfWeekTextView = itemView.findViewById(R.id.textViewDayOfWeek);
            dateTextView = itemView.findViewById(R.id.textViewDate);
            weightTextView = itemView.findViewById(R.id.textViewWeight);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }
}