package com.zybooks.healthapp;

public class User {
    private String name;
    private String username;
    private String password;
    private double goalWeight;
    private int id;

    // Constructor
    public User(int id, String name, String username, String password, double goalWeight) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
        this.goalWeight = goalWeight;
    }

    // Constructors
    public User(String name, String username, String password, double goalWeight) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.goalWeight = goalWeight;
        this.id = -1;
    }

    // Constructor username
    public User(String username) {
        this.username = username;
        this.name = "";
        this.password = "";
        this.goalWeight = 0.0;
        this.id = -1;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(double goalWeight) {
        this.goalWeight = goalWeight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", username='" + username + '\'' +
                ", goalWeight=" + goalWeight +
                '}';
    }
}
