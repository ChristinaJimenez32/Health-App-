package com.zybooks.healthapp;

import android.database.sqlite.SQLiteDatabase;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.SharedPreferences;


public class MainActivity extends AppCompatActivity {

    // TextView declarations
    TextView textLogin;
    TextView textName;
    TextView textPassword;
    TextView textNewLogin;

    // EditText declarations
    EditText usernameBox;
    EditText passwordBox;

    // Button Declarations
    Button buttonLogin;
    Button buttonNewAccount;

    //SQLiteDatabase
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements

        // TextView elements
        textLogin = findViewById(R.id.textLogin);
        textName = findViewById(R.id.textName);
        textPassword = findViewById(R.id.textPassword);
        textNewLogin = findViewById(R.id.newLoginText);

        // EditText elements
        usernameBox = findViewById(R.id.userNameEditText);
        passwordBox = findViewById(R.id.EditTextPassword);

        // Button elements
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonNewAccount = findViewById(R.id.NewAccountButton);

        // Start buttons as disabled/enabled
        buttonLogin.setEnabled(false);
        buttonNewAccount.setEnabled(true);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        // Set text change listener
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean enableButton = !usernameBox.getText().toString().trim().isEmpty() &&
                        !passwordBox.getText().toString().trim().isEmpty();
                buttonLogin.setEnabled(enableButton);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };

        // TextWatcher usernameBox and passwordBox
        usernameBox.addTextChangedListener(textWatcher);
        passwordBox.addTextChangedListener(textWatcher);


        //onClickListener for Login Button and takes to weightDiary
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get input values
                String username = usernameBox.getText().toString().trim();
                String password = passwordBox.getText().toString().trim();

                //input validation
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);

                boolean userAuthentication = dbHelper.checkUser(username, password);

                if (userAuthentication) {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                    //saves login State
                    SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean("is_logged_in", true);
                    editor.putString("username", username);
                    editor.apply();

                    Intent intent = new Intent(MainActivity.this, WeightDiaryActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();

                }
            }
        });



        //onClickListener for buttonNewAccount takes to create Account Activity
        buttonNewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewUserActivity.class);
                startActivity(intent);
            }
        });

    }
    }
