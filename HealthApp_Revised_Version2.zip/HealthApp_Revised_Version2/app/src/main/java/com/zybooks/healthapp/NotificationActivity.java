package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private EditText phoneNumberEditText;
    private Button agreeButton;
    private Button declineButton;
    private Button receiveSmsButton;
    private String currentUsername;

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_layout);

        // Retrieve the username from intent
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");

        // Initialize the views
        phoneNumberEditText = findViewById(R.id.idPhoneEdit);
        agreeButton = findViewById(R.id.agreeButton);
        declineButton = findViewById(R.id.declineButton);
        receiveSmsButton = findViewById(R.id.recieveSMSbutton);

        // Set listeners
        agreeButton.setOnClickListener(v -> onAgreeClicked());
        declineButton.setOnClickListener(v -> onDeclineClicked());

        // Disable phone number input and SMS buttons initially
        phoneNumberEditText.setEnabled(false);
        receiveSmsButton.setEnabled(false);

        // Set up drawer layout
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Setup the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void onAgreeClicked() {
        // Enable phone number input and button
        phoneNumberEditText.setEnabled(true);
        receiveSmsButton.setEnabled(true);

        // SMS when clicked
        receiveSmsButton.setOnClickListener(v -> onReceiveSmsClicked());
    }

    private void onDeclineClicked() {
        finish();
    }

    private void onReceiveSmsClicked() {
        String phoneNumber = phoneNumberEditText.getText().toString();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Use the currentUsername directly
        String username = currentUsername;

        // Initialize the database helper
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Fetch the user information
        User user = dbHelper.getUser(username);
        if (user == null) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }


        double goalWeight = user.getGoalWeight();

        // Get latest weight entry
        float latestWeight = dbHelper.getLatestWeight(username);

        // Check if the latest weight = goal
        if (latestWeight == goalWeight) {

            sendSmsNotification(phoneNumber);
        } else {
            Toast.makeText(this, "Goal weight not reached yet", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSmsNotification(String phoneNumber) {
        String message = "Congratulations! You've reached your goal weight!";

        // Check SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Send SMS if permission is granted
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS notification sent", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS
                String phoneNumber = phoneNumberEditText.getText().toString();
                sendSmsNotification(phoneNumber);
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            // Open Weight Diary Activity
            Intent intent = new Intent(this, WeightDiaryActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_food_diary) {
            Intent intent = new Intent(this, FoodDiaryActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_sms_notification) {
            // Already in SMS
            Toast.makeText(this, "Already in SMS Notifications", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_user_profile) {
            // Open User edit account profile Activity
            Intent intent = new Intent(this, EditAccountActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE)
                .edit()
                .clear()
                .apply();

        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
