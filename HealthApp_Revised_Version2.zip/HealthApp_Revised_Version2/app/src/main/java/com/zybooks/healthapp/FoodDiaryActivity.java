package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class FoodDiaryActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private RecyclerView recyclerView;
    private FoodDiaryAdapter adapter;
    private List<DayEntry> weekDays;
    private TextView weekLabelTextView;
    private Button btnPreviousWeek, btnNextWeek;

    private DatabaseHelper databaseHelper;
    private String username;
    private Calendar currentWeekStart;

    // Drawer elements
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_diary);
        // Get username from intent
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize current week to current date
        currentWeekStart = Calendar.getInstance();
        currentWeekStart.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        // Initialize UI components
        weekLabelTextView = findViewById(R.id.textViewWeekLabel);
        btnPreviousWeek = findViewById(R.id.btnPreviousWeek);
        btnNextWeek = findViewById(R.id.btnNextWeek);
        recyclerView = findViewById(R.id.recyclerView);

        // Setup Recycler
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        // Load initial week
        loadWeekData();

        // Week listeners
        btnPreviousWeek.setOnClickListener(v -> {
            currentWeekStart.add(Calendar.WEEK_OF_YEAR, -1);
            loadWeekData();
        });

        btnNextWeek.setOnClickListener(v -> {
            currentWeekStart.add(Calendar.WEEK_OF_YEAR, 1);
            loadWeekData();
        });

        // Setup DrawerLayout and navigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Food Diary");

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void loadWeekData() {
        // Generate 7 days
        weekDays = generateWeekDays();

        // Update week
        SimpleDateFormat labelFormat = new SimpleDateFormat("MMM dd", Locale.US);
        Calendar weekEnd = (Calendar) currentWeekStart.clone();
        weekEnd.add(Calendar.DAY_OF_MONTH, 6);

        String weekLabel = "Week of " + labelFormat.format(currentWeekStart.getTime()) +
                " - " + labelFormat.format(weekEnd.getTime());
        weekLabelTextView.setText(weekLabel);

        // Create adapter
        if (adapter == null) {
            adapter = new FoodDiaryAdapter(weekDays, this, username, databaseHelper);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.updateData(weekDays);
        }
    }

    private List<DayEntry> generateWeekDays() {
        List<DayEntry> days = new ArrayList<>();
        Calendar calendar = (Calendar) currentWeekStart.clone();

        String[] dayNames = {"Sunday", "Monday", "Tuesday", "Wednesday",
                "Thursday", "Friday", "Saturday"};

        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
        SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        for (int i = 0; i < 7; i++) {
            DayEntry day = new DayEntry();
            day.setDayOfWeek(dayNames[i]);
            day.setDate(dateFormat.format(calendar.getTime()));
            day.setDateString(dbDateFormat.format(calendar.getTime()));

            // Load food entries from database for specific date
            int entryCount = databaseHelper.getFoodEntryCount(username, day.getDateString());
            day.setEntryCount(entryCount);

            days.add(day);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        return days;
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadWeekData();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            Intent intent = new Intent(this, WeightDiaryActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_sms_notification) {
            Intent intent = new Intent(this, NotificationActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_user_profile) {
            Intent intent = new Intent(this, EditAccountActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else if (id == R.id.nav_food_diary) {
            Toast.makeText(this, "You are already in Food Diary", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}