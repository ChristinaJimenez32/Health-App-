package com.zybooks.healthapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class WeightDiaryActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener, WeightAdapter.OnDeleteClickListener, WeightAdapter.OnItemClickListener {

    private RecyclerView weightRecyclerView;
    private WeightAdapter weightAdapter;
    private DatabaseHelper databaseHelper;
    private String currentUsername;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private List<WeightEntry> weightEntries;
    private EditText weightEditText;
    private Button submitWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_grid);

        // Retrieve the username from Intent
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize RecyclerView
        weightRecyclerView = findViewById(R.id.recyclerView);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load weight entries for the current user
        loadWeightEntries();

        // Initialize input fields and button
        weightEditText = findViewById(R.id.editTextWeight);
        submitWeightButton = findViewById(R.id.buttonAdd);

        // Submit button click listener
        submitWeightButton.setOnClickListener(v -> {
            String weightStr = weightEditText.getText().toString().trim();

            if (weightStr.isEmpty()) {
                Toast.makeText(WeightDiaryActivity.this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            float weight = Float.parseFloat(weightStr);
            String currentDate = new java.text.SimpleDateFormat("MM-dd-yyyy").format(new java.util.Date());

            // Insert the new weight entry into the database
            boolean success = databaseHelper.insertWeight(currentUsername, currentDate, weight);

            if (success) {
                Toast.makeText(WeightDiaryActivity.this, "Weight entry added!", Toast.LENGTH_SHORT).show();
                loadWeightEntries();
                weightEditText.setText("");
            } else {
                Toast.makeText(WeightDiaryActivity.this, "Failed to add weight entry.", Toast.LENGTH_SHORT).show();
            }
        });

        // Setups the drawer layout and navigation view
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Toolbar for the navigation drawer
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void loadWeightEntries() {
        weightEntries = new ArrayList<>();
        Cursor cursor = databaseHelper.getWeightEntries(currentUsername);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT));
                weightEntries.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }

        // adapter intialization
        weightAdapter = new WeightAdapter(weightEntries, this, this);
        weightRecyclerView.setAdapter(weightAdapter);
    }

    // Handle delete button click
    @Override
    public void onDeleteClick(WeightEntry weightEntry) {
        boolean deleted = databaseHelper.deleteWeightEntry(weightEntry.getId());
        if (deleted) {
            Toast.makeText(this, "Entry deleted!", Toast.LENGTH_SHORT).show();
            loadWeightEntries();
        } else {
            Toast.makeText(this, "Delete failed!", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle editing
    @Override
    public void onItemClick(WeightEntry weightEntry) {
        showEditWeightDialog(weightEntry);
    }

    private void showEditWeightDialog(WeightEntry weightEntry) {
        //box for edit text
        final EditText editWeightInput = new EditText(this);
        editWeightInput.setText(String.valueOf(weightEntry.getWeight()));


        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry")
                .setView(editWeightInput)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newWeightStr = editWeightInput.getText().toString().trim();

                    if (newWeightStr.isEmpty()) {
                        Toast.makeText(WeightDiaryActivity.this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    float newWeight = Float.parseFloat(newWeightStr);

                    // Update the weight entry in the database
                    boolean success = databaseHelper.updateWeightEntry(weightEntry.getId(), newWeight);
                    if (success) {
                        Toast.makeText(WeightDiaryActivity.this, "Weight entry updated!", Toast.LENGTH_SHORT).show();
                        loadWeightEntries(); // Refresh the list after updating
                    } else {
                        Toast.makeText(WeightDiaryActivity.this, "Failed to update weight entry.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            Toast.makeText(this, "You are already in Weight Diary", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_sms_notification) {
            startActivity(new Intent(this, NotificationActivity.class));
        } else if (id == R.id.nav_user_profile) {
            Intent intent = new Intent(this, EditAccountActivity.class);
            intent.putExtra("username", currentUsername);
            startActivity(intent);
        } else if (id == R.id.nav_logout) {
            logoutUser();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
