package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class NewUserActivity extends AppCompatActivity {

    //TextView Declarations

    TextView createAccountTextView;
    TextView nameTextView;
    TextView usernameTextView;
    TextView passwordTextView;
    TextView goalWeightTextView;



    //EditText Declarations

    EditText nameEditText;
    EditText usernameEditText;
    EditText passwordEditText;
    EditText goalWeightEditText;

    //Button Declaration

    Button createAccountButton;
    Button cancelAccountButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);

        // Initialize UI elements

        //TextView elements
        
        createAccountTextView = findViewById(R.id.createAccountTextView);
        nameTextView = findViewById(R.id.nameTextView);
        usernameTextView = findViewById(R.id.userNameTextView);
        passwordTextView = findViewById(R.id.passwordTextView);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);

        //EditText elements
        nameEditText = findViewById(R.id.nameEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);


        //Button element
        createAccountButton = findViewById(R.id.createAccountButton);
        cancelAccountButton = findViewById(R.id.cancelAccountButton);

        //button Enabling
        createAccountButton.setEnabled(false);
        cancelAccountButton.setEnabled(true);


        // Set text change listener for createAccount Button
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean enableButton = !usernameEditText.getText().toString().trim().isEmpty() &&
                        !passwordEditText.getText().toString().trim().isEmpty() &&
                        !nameEditText.getText().toString().trim().isEmpty() &&
                        !goalWeightEditText.getText().toString().trim().isEmpty();
                createAccountButton.setEnabled(enableButton);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };
        // TextWatcher to both username, password, name, goal weight
        usernameEditText.addTextChangedListener(textWatcher);
        nameEditText.addTextChangedListener(textWatcher);
        nameEditText.addTextChangedListener(textWatcher);
        goalWeightEditText.addTextChangedListener(textWatcher);

        //onClickListener to switch activities upon button click
        cancelAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewUserActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });
        //onClickListener for the  Create Button -> takes to weightDiary
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Gets input values
                String name = nameEditText.getText().toString().trim();
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                String goalWeightStr = goalWeightEditText.getText().toString().trim();

                // Validate input
                if (name.isEmpty() || username.isEmpty() || password.isEmpty() || goalWeightStr.isEmpty()) {
                    Toast.makeText(NewUserActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                float goalWeight = Float.parseFloat(goalWeightStr); // Convert weight input to float
                DatabaseHelper dbHelper = new DatabaseHelper(NewUserActivity.this);

                // Inserts user into database
                boolean success = dbHelper.insertUser(name, username, password, goalWeight);

                if (success) {
                    Toast.makeText(NewUserActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(NewUserActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Close this activity
                } else {
                    Toast.makeText(NewUserActivity.this, "Error: Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    }
